package com.example.express_sharing_app

import android.os.Parcel
import android.os.Parcelable

data class ListOfDescription (
    val listDescription :List<Description> = ArrayList<Description>()
        ){
//    constructor(parcel: Parcel) : this(parcel.createTypedArrayList(Description)?:ArrayList()) {
//    }
//
//    override fun writeToParcel(parcel: Parcel, flags: Int) {
//        parcel.writeTypedList(listDescription)
//    }
//
//    override fun describeContents()=0
//
//    companion object CREATOR : Parcelable.Creator<ListOfDescription> {
//        override fun createFromParcel(parcel: Parcel): ListOfDescription {
//            return ListOfDescription(parcel)
//        }
//
//        override fun newArray(size: Int): Array<ListOfDescription?> {
//            return arrayOfNulls(size)
//        }
//    }
}