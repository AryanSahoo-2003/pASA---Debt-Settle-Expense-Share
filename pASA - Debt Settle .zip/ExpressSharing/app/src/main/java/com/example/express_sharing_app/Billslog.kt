package com.example.express_sharing_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObject

class Billslog : AppCompatActivity() {
    private lateinit var recyclerView2: RecyclerView
    private lateinit var finBill : ArrayList<DebtSettleClass>
    private lateinit var billLogAdapter: billsAdapter
    private lateinit var linkmodel:ArrayList<Description>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_billslog)
        recyclerView2=findViewById(R.id.DebtRecyclerView)
        recyclerView2.setHasFixedSize(true)
        recyclerView2.layoutManager = LinearLayoutManager(this)

        finBill= ArrayList()

        var BillGrp : ArrayList<Members>  = ArrayList()
        var tempalpha = ArrayList<MoneyList>()

//start
        FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid).collection("collection")
            .document(intent.getStringExtra("Title").toString()).get().addOnSuccessListener {documentSnapshot ->
                BillGrp = documentSnapshot.toObject<ArrayList<Members>>()!!
                Log.d("hemloBills",BillGrp.toString())

            }
//        end
//        linkmodel = ArrayList()
//        FirebaseFirestore.getInstance().collection("USERS").document(
//            FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").addSnapshotListener { value, error ->
//
//
//            for (dc: DocumentChange in value?.documentChanges!!) {
//                if (dc.type == DocumentChange.Type.ADDED) {
//                    linkmodel.add(dc.document.toObject(Description::class.java))
//                }
//            }

//        var alpha : String = linkmodel.get(0).Title
////        BillGrp = linkmodel.get(intent.getIntExtra("positionGrp",-1)).memberlist
//        Toast.makeText(this,alpha,Toast.LENGTH_SHORT).show()
//            tempalpha.add(MoneyList(32.33, "hi"))
//            BillGrp.add(Members("hello", 23, tempalpha))

            for (items in BillGrp.indices) {
                for (alpha in BillGrp[items].memberList.indices) {
                    finBill.add(
                        DebtSettleClass(
                            BillGrp[items].memberList[alpha].finalPayer,
                            BillGrp[items].memberList[alpha].debt,
                            BillGrp[items].senderGive
                        )
                    )
                }
            }
//            billLogAdapter = billsAdapter(finBill,this)
//            recyclerView2.adapter = billLogAdapter
//            billLogAdapter.notifyDataSetChanged()
        }
    }


