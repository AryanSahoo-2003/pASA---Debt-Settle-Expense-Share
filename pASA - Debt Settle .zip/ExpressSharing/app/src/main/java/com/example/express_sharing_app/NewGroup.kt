package com.example.express_sharing_app

import android.content.Intent
import android.icu.text.CaseMap.Title
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class NewGroup : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_group)
        val createBtn=findViewById<Button>(R.id.CreateGrp)
        val grpName=findViewById<EditText>(R.id.GrpName)
        var memberList : ArrayList<Members>
        val reason=findViewById<EditText>(R.id.Reason)
        val displayName=intent.getStringExtra("name")
        val checkNewGrp=true
        var beta:Int=0
        val strReason=reason.text.toString()

        val db = FirebaseFirestore.getInstance()//main root

//        var listOfMem:MutableList<Members> = mutableListOf<Members>()
//        listOfMem.add(Members(displayName.toString()))//for creating 1 member
//        var hemlo = Song("3233",grpName.text.toString()+beta.toString(),reason.text.toString(), listOfMem as ArrayList<Members>)
//
//        val betap: Int=0
        createBtn.setOnClickListener {
//
//            db.collection("USERS").add(Description("jnjnj","m","knj"))
//            db.collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid).collection("collection")
//                .add(FieldValue.arrayUnion(Description("1",grpName.text.toString(),reason.text.toString())))
               var temp : ArrayList<MoneyList> = ArrayList()
               var temp1:ArrayList<String> = ArrayList()
               var temp2:ArrayList<String> = ArrayList()
                memberList = ArrayList()
                memberList.add(Members("Aryan",0,temp))
            val hashMap = hashMapOf<String, Any>(
                "Title" to grpName.text.toString(),
                "Reason" to reason.text.toString(),
                "memberlist" to memberList,
                "emailList" to temp1,
                "Memberskitne" to temp2
            )

            db.collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").document(grpName.text.toString())
                .set(hashMap)
                .addOnSuccessListener {
//                Log.d(TAG, "Added document with ID ${it.id}")

                }
                .addOnFailureListener { exception ->
                        }


            val intent : Intent = Intent(this , MainScreen::class.java)
            intent.putExtra("GroupName",grpName.text.toString())
            intent.putExtra("Reason",reason.text.toString())
            intent.putExtra("check", checkNewGrp)
            intent.putExtra("name",displayName)
//            intent.putExtra("betap",betap)
            startActivity(intent)

        }

    }

}