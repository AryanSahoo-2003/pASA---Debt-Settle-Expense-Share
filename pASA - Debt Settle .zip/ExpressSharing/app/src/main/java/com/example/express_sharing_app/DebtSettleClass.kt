package com.example.express_sharing_app

data class DebtSettleClass(var fromWho:String="",var amountPay:Double=0.0,var toWhom:String=""){}
