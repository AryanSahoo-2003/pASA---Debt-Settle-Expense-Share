package com.example.express_sharing_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class billsAdapter(val billsList : ArrayList<DebtSettleClass>):RecyclerView.Adapter<billsAdapter.billsViewHolder>()
{
    class billsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
         var dena = itemView.findViewById<TextView>(R.id.dena)
        var kitna = itemView.findViewById<TextView>(R.id.kitna)
        var lena = itemView.findViewById<TextView>(R.id.lena)



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): billsViewHolder {
        val viewBill = LayoutInflater.from(parent.context).inflate(R.layout.bills_each_item,parent,false)
        return billsViewHolder(viewBill)
    }

    override fun getItemCount(): Int {
        return billsList.size
    }

    override fun onBindViewHolder(holder: billsViewHolder, position: Int) {
        val billItem = billsList[position]
        holder.dena.text=billItem.fromWho
        holder.kitna.text= billItem.amountPay.toString()
        holder.lena.text=billItem.toWhom

    }


}