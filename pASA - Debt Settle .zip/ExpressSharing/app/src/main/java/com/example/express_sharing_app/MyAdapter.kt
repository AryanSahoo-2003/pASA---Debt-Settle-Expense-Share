package com.example.express_sharing_app

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(val GrpDescription:ArrayList <Description>):RecyclerView.Adapter<MyAdapter.MyViewHolder>(){

    private lateinit var mListener : onItemClickListener

    interface onItemClickListener{
        fun onItemClick(position: Int)

    }

    fun setOnItemClickListener(listener: onItemClickListener){
        mListener=listener
    }




    //
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater:LayoutInflater=LayoutInflater.from(parent.context)//return layout to java
        val view = inflater.inflate(R.layout.item_view,parent,false)
        return MyViewHolder(view,mListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.txtTitle.text=GrpDescription[position].Title
        holder.txtReason.text=GrpDescription[position].Reason

    }

    override fun getItemCount(): Int {
        return GrpDescription.size
    }
    class MyViewHolder(itemView: View,listener: onItemClickListener) : RecyclerView.ViewHolder(itemView) {
        var  txtTitle=itemView.findViewById<TextView>(R.id.GroupNameItemView)
        var txtReason = itemView.findViewById<TextView>(R.id.ReasonItemView)
        init {
            itemView.setOnClickListener {
                listener.onItemClick(adapterPosition)
            }
        }

        }

    }


