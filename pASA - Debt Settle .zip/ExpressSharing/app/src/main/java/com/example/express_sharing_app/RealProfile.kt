package com.example.express_sharing_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth

class RealProfile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_real_profile)

        findViewById<TextView>(R.id.emailProfile).text = FirebaseAuth.getInstance().currentUser!!.email.toString()
        findViewById<TextView>(R.id.emailProfile).setOnClickListener{
            val intent : Intent = Intent(this , MainScreen::class.java)
            intent.putExtra("name",intent.getStringExtra("name"))
            startActivity(intent)
        }
    }
}