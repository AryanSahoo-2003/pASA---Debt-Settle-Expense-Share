package com.example.express_sharing_app

import android.os.Parcel
import android.os.Parcelable
import java.io.Serializable

data class Members(
    val senderGive :String="",
    var money : Int = 0,
    val memberList: ArrayList<MoneyList> = ArrayList())
//):    Parcelable
//{
//    constructor(parcel: Parcel) : this(
//        parcel.readInt(),
//        parcel.readString()!!
//    ) {
//    }
//
//    override fun describeContents()=0
//
//    override fun writeToParcel(p0: Parcel, p1: Int) =with(p0){
//        writeInt(money)
//        writeString(memberList)
//        TODO("Not yet implemented")
//    }
//
//    companion object CREATOR : Parcelable.Creator<Members> {
//        override fun createFromParcel(parcel: Parcel): Members {
//            return Members(parcel)
//        }
//
//        override fun newArray(size: Int): Array<Members?> {
//            return arrayOfNulls(size)
//        }
//    }
//}
