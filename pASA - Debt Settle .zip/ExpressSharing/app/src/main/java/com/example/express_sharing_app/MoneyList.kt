package com.example.express_sharing_app

data class MoneyList(
    var debt:Double = 0.0,
    var finalPayer : String =""
) {
}