package com.example.express_sharing_app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.ktx.Firebase

class FirestoreClass {

    private val mFireStore = FirebaseFirestore.getInstance()

    fun registerUser(activity:MainActivity,userInfo:GroupList){
        val listOfMem:MutableList<Members> = mutableListOf<Members>()
        val hemlo = Description("", "",listOfMem as ArrayList<Members>)
            val beta :ArrayList<Description> = ArrayList()
        beta.add(hemlo)
        val grpList= GroupList(getCurrentUserId(),beta)
            mFireStore.collection("USERS").document(getCurrentUserId())
                .set(userInfo, SetOptions.merge())

        mFireStore.collection("USERS").document(getCurrentUserId()).update("groupName", FieldValue.arrayUnion(hemlo))
        mFireStore.collection("USERS").document(getCurrentUserId()).update("memberlist", FieldValue.delete())
        mFireStore.collection("USERS").document(getCurrentUserId()).update("reason", FieldValue.delete())
        mFireStore.collection("USERS").document(getCurrentUserId()).update("title", FieldValue.delete())

    }

    fun getCurrentUserId():String{
        return FirebaseAuth.getInstance().currentUser!!.uid
    }


}