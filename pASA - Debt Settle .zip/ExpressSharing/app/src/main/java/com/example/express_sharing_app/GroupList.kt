package com.example.express_sharing_app

import android.os.Parcel
import android.os.Parcelable

data class GroupList(
    var id:String="",
    val GroupName :ArrayList<Description> = ArrayList()
) {
    fun getid(): String{
        return id
    }

//    constructor(parcel: Parcel) : this(
//        parcel.readString().toString(),
//        parcel.createTypedArrayList(Description.CREATOR)?:ArrayList()
//    ) {
//    }
//
//    override fun describeContents()=0
//
//    override fun writeToParcel(p0: Parcel, p1: Int) = with(p0) {
//        writeString(id)
//        writeTypedList(GroupName)
//    }
//
//    companion object CREATOR : Parcelable.Creator<GroupList> {
//        override fun createFromParcel(parcel: Parcel): GroupList {
//            return GroupList(parcel)
//        }
//
//        override fun newArray(size: Int): Array<GroupList?> {
//            return arrayOfNulls(size)
//        }
//    }
}