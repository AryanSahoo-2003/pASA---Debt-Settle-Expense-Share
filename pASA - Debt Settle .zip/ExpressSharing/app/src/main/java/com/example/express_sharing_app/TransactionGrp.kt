package com.example.express_sharing_app


import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.CaseMap.Title
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.DatePicker
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.time.Year
import java.util.Calendar
import java.util.Locale

class TransactionGrp : AppCompatActivity(),DatePickerDialog.OnDateSetListener,TimePickerDialog.OnTimeSetListener {
    var day = 0
    var month = 0
    var year = 0
    var hour =0
    var minute = 0

    var savedDay = 0
    var savedMonth = 0
    var savedYear = 0
    var savedHour = 0
    var savedMinute =0

    var newtoWhom : String = ""
    var newfromWhom : String= ""
    var newamountpay : Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction_grp)


        newtoWhom=intent.getStringExtra("newtoWhome").toString()
        newfromWhom=intent.getStringExtra("newfromWho").toString()
        newamountpay=intent.getIntExtra("newamountPay",0)
        findViewById<EditText>(R.id.JoBhejRhaHai).hint=newtoWhom
        findViewById<EditText>(R.id.MemEditScroll).hint=newfromWhom
        findViewById<EditText>(R.id.AmtScrollEdit).hint = newamountpay.toString()

        var transactionListMem : ArrayList<String> = ArrayList()
        var transactionListAmt : ArrayList<String> = ArrayList()
        var memberList_TransactionGrp : ArrayList<MoneyList> = ArrayList()
        var split = -1
        findViewById<Button>(R.id.splitByAmount).setOnClickListener{
            split=0
        }
        findViewById<Button>(R.id.splitByShare2).setOnClickListener{
            split=1
        }



        findViewById<Button>(R.id.saveTransaction).setOnClickListener{

            var AmtScrollEdit =findViewById<EditText>(R.id.AmtScrollEdit).text
            var MemScrollEdit =findViewById<EditText>(R.id.MemEditScroll).text
            var str :String = ""
            for(i in AmtScrollEdit.indices){
                if(AmtScrollEdit[i]=='\n'){
                    str=""
                    continue
                }
                str+=AmtScrollEdit[i]
                if(i!=(AmtScrollEdit.length-1)&& AmtScrollEdit[i+1]=='\n'){
                    transactionListAmt.add(str)
                }
            }
            var btr=""
            for(j in MemScrollEdit.indices){
                if(MemScrollEdit[j]=='\n'){
                    btr=""
                    continue
                }
                btr+=MemScrollEdit[j]
                if(j!=(MemScrollEdit.length-1)&&MemScrollEdit[j+1]=='\n'){
                    transactionListMem.add(btr)
                }
            }

            if(split==0){
                var count = 0
                for(i in transactionListMem.indices){
                    count+=1
                }
                var eachAmt = findViewById<EditText>(R.id.TotalExpenseValue).text.toString().toDouble()
                eachAmt /= count
                for(i in transactionListMem.indices){
                    memberList_TransactionGrp.add(MoneyList(eachAmt,transactionListMem[i]))
   //                 FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
   //                     .collection("collection").document(intent.getStringExtra("Title")!!).update("memberlist",FieldValue.arrayUnion(MoneyList(eachAmt,transactionListMem[i])))
                }
            }
            else if(split==1){
                var totalDenominator = 0
               for(j in transactionListAmt.indices){
                   totalDenominator+=transactionListAmt[j].toInt()
               }

                for(j in transactionListAmt.indices){
                    var eachAmt = findViewById<EditText>(R.id.TotalExpenseValue).text.toString().toDouble()
                   var numerator : Double = transactionListAmt[j].toDouble()/totalDenominator
                    memberList_TransactionGrp.add(MoneyList(numerator*eachAmt,transactionListMem[j]))
   //                 FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
   //                     .collection("collection").document(intent.getStringExtra("Title")!!).update("memberList",FieldValue.arrayUnion(MoneyList(numerator*eachAmt,transactionListMem[j])))
                }

            }

            var tempMem = Members(findViewById<EditText>(R.id.JoBhejRhaHai).text.toString(),findViewById<EditText>(R.id.TotalExpenseValue).text.toString().toInt(),memberList_TransactionGrp)
            memberList_TransactionGrp=ArrayList()
            transactionListMem= ArrayList()
            transactionListAmt=ArrayList()
           FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
               .collection("collection").document(intent.getStringExtra("Title")!!).update("memberlist",FieldValue.arrayUnion(tempMem) )
  //         FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
  //              .collection("collection").document(intent.getStringExtra("Title")!!).update("money",findViewById<EditText>(R.id.TotalExpenseValue).text.toString())



        }


        //for date picker
        findViewById<ImageView>(R.id.DatePicker).setOnClickListener{
            getDateCalender()
            DatePickerDialog(this,this,year,month,day).show()
        }
        //end
        findViewById<Button>(R.id.Debt).setOnClickListener{
            val tempintent = Intent(this@TransactionGrp,TemporaryChupa::class.java)
            tempintent.putExtra("positionGrp",intent.getIntExtra("positionGrp",-1))
            startActivity(tempintent)
        }
    }
    private fun getDateCalender(){
        val cal= Calendar.getInstance()
        day = cal.get(Calendar.DAY_OF_MONTH)
        month=cal.get(Calendar.MONTH)
        year=cal.get(Calendar.YEAR)
        hour = cal.get(Calendar.HOUR)
        minute=cal.get(Calendar.MINUTE)
    }
    override fun onDateSet(view: DatePicker?, p1: Int, p2: Int, p3: Int) {

        savedDay = p3
        savedMonth = p2
        savedYear=p1
        getDateCalender()
        TimePickerDialog(this@TransactionGrp,this@TransactionGrp,hour,minute,true).show()

        TODO("Not yet implemented")
    }

    override fun onTimeSet(view: TimePicker?, p1: Int, p2: Int) {
        savedHour = p1
        savedMinute = p2
        Toast.makeText(this@TransactionGrp,"$savedDay-$savedMonth-$savedYear\n$savedHour-$savedMinute",Toast.LENGTH_LONG).show()
    }


}