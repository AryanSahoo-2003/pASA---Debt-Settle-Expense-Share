package com.example.express_sharing_app

data class listOfmemberlist(
    var listOfmemberlist : ArrayList<Members> = ArrayList()
)
