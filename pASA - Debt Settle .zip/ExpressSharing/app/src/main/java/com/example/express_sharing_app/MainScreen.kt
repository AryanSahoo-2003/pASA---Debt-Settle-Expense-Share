package com.example.express_sharing_app

import android.content.Intent
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase


class MainScreen : AppCompatActivity() {

    private lateinit var auth : FirebaseAuth
    private lateinit var displayNam : String

    private lateinit var recyclerView: RecyclerView
    private lateinit var myAdapter: MyAdapter
    private lateinit var linkmodel: ArrayList<Description>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)

        val popBtn =findViewById<Button>(R.id.PopBtn)


        registerForContextMenu(popBtn)
        auth = Firebase.auth

        val email = intent.getStringExtra("email")
        displayNam = FirebaseAuth.getInstance().currentUser!!.displayName.toString()
        val checkFromNewGrp=intent.getBooleanExtra("check",false)
        findViewById<TextView>(R.id.Name).setText("Welcome " + displayNam.toString().lowercase() + " !")


        recyclerView=findViewById(R.id.recylerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)


        linkmodel = ArrayList()


        EventChangeListner()





//        findViewById<Button>(R.id.retrieve).setOnClickListener{
//
//
//        }
//



        findViewById<Button>(R.id.SignOut).setOnClickListener {
            Firebase.auth.signOut()
            startActivity(Intent(this , MainActivity::class.java))
        }
    }

    private fun EventChangeListner() {

        var s:String=""
        FirebaseFirestore.getInstance().collection("USERS").document(
            FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").addSnapshotListener { value, error ->

//            linkmodel.addAll(value!!.toObjects(Description::class.java))
            var simp:String = String()
            //start
            for(dc : DocumentChange in value?.documentChanges!!){
                if (dc.type==DocumentChange.Type.ADDED){
                    linkmodel.add(dc.document.toObject(Description::class.java))
                }
            }
            myAdapter=MyAdapter(linkmodel)
            recyclerView.adapter=myAdapter

            myAdapter.setOnItemClickListener(object :MyAdapter.onItemClickListener{
                override fun onItemClick(position: Int) {
                    val textShow=linkmodel.get(position).Title
                    Toast.makeText(this@MainScreen,"Welcome to $textShow",Toast.LENGTH_SHORT).show()
                     val intent= Intent(this@MainScreen,EachGroupDescription::class.java)
                    intent.putExtra("Title",linkmodel.get(position).Title)
                    intent.putExtra("Reason",linkmodel.get(position).Reason)
                    intent.putExtra("positionGrp",position)
                    intent.putExtra("name",displayNam)
//                    intent.putParcelableArrayListExtra("memberlist",linkmodel.get(position).memberlist)

//                    EachGroupDescription.setDetailsUser(linkmodel.get(position).Title)
                    startActivity(intent)
                }
            })
            myAdapter.notifyDataSetChanged()

            //end

            //initialCode1
//            for(item in linkmodel.indices){
//                val hello = linkmodel.get(item).Title.toString()
//                simp+=hello+"   "
//            }
//
//            Log.d("text", s)
//            findViewById<TextView>(R.id.ShowTxt).text=simp

            //EndInitialCode2

        }

    }


    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        menuInflater.inflate(R.menu.pop_menu,menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        when(item.itemId){
            R.id.profile -> AboutProfile()
            R.id.NewGrp -> updateUI2()
            R.id.About -> ABoutActivity()
        }
        return super.onContextItemSelected(item)
    }
    private fun updateUI2(){
        val intent : Intent = Intent(this , NewGroup::class.java)
        intent.putExtra("name",displayNam)

        startActivity(intent)
    }
    private fun ABoutActivity(){
        val intent : Intent = Intent(this,Profile::class.java)
        Toast.makeText(this,"About Section",Toast.LENGTH_SHORT).show()
        intent.putExtra("name",displayNam)
        startActivity(intent)
    }
    private fun AboutProfile(){
        val intent : Intent = Intent(this,RealProfile::class.java)
        Toast.makeText(this,"Profile Section",Toast.LENGTH_SHORT).show()
        intent.putExtra("name",displayNam)
        startActivity(intent)
    }
}
