package com.example.express_sharing_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.type.Money
import java.io.Serializable

class EachGroupDescription : AppCompatActivity() {
//    private lateinit var secondRecyclerView:RecyclerView
    private var memberlist :ArrayList<Members> = ArrayList()
    private lateinit var DebtAdapter : Second_MyAdapter

    private var listMember : ArrayList<String> = ArrayList()
    private var listEmail : ArrayList<String> =ArrayList()

    private lateinit var linkmodel: ArrayList<Description>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_each_group_description)


        val NewMember=findViewById<Button>(R.id.NewMember)
        val Title=intent.getStringExtra("Title")
        findViewById<TextView>(R.id.GroupName_Desciption).text=Title.toString()
        val Reason=intent.getStringExtra("Reason")
        findViewById<TextView>(R.id.Reason_TextView).text=Reason.toString()
        var scrollMemberList=findViewById<TextView>(R.id.TextViewMembers)
        var scrollemailList=findViewById<TextView>(R.id.emailTextView)

//        FirebaseFirestore.getInstance().collection("USERS").document(
//            FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").addSnapshotListener { value, error ->
//
////            linkmodel.addAll(value!!.toObjects(Description::class.java))
//            var simp:String = String()
//            //start
//            for(dc : DocumentChange in value?.documentChanges!!){
//                if (dc.type== DocumentChange.Type.ADDED){
//                    linkmodel.add(dc.document.toObject(Description::class.java))
//                }
//            }
//            }
//        memberlist = linkmodel.get(intent.getIntExtra("positionGrp",-1)).memberlist
//        memberlist.add(Members("Aryan",0,"Aryan"))
//        memberlist.add(Members("Aryan",500,"Atul"))

      findViewById<ImageView>(R.id.delete).setOnClickListener{
          FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
              .collection("collection").document(Title!!).delete().addOnSuccessListener {
                  Toast.makeText(this@EachGroupDescription,"$Title named Group Sucessfully deleted",Toast.LENGTH_LONG).show()
              }
          val intentToMainScreen = Intent(this@EachGroupDescription,MainScreen::class.java)
          intentToMainScreen.putExtra("name",intent.getStringExtra("name"))
          startActivity(intentToMainScreen)
      }
      FirebaseFirestore.getInstance().collection("USERS").document( FirebaseAuth.getInstance().currentUser!!.uid)
          .collection("collection").document(Title!!).get().addOnSuccessListener { documentSnapshot ->
              var eachGrp = documentSnapshot.toObject(Description::class.java)
              listMember = eachGrp!!.Memberskitne
              listEmail = eachGrp.emailList
              var str=""
              for(items in listMember.indices){
                  str+=listMember[items]
                  str+="\n"
              }

              scrollMemberList.text=str
              var btr=""
              for(item in listEmail.indices){
                  btr+=listEmail[item]
                  btr+="\n"
              }
              scrollemailList.text=btr

          }



//        }
        memberlist= ArrayList()



//        secondRecyclerView = findViewById(R.id.SecondRecyclerView)
//        secondRecyclerView.setHasFixedSize(true)
//        secondRecyclerView.layoutManager= LinearLayoutManager(this)
//        DebtAdapter= Second_MyAdapter(memberlist)
//        secondRecyclerView.adapter = DebtAdapter









        findViewById<Button>(R.id.transactionBtn).setOnClickListener{
            val intentEachGroupDescription = Intent(this,TransactionGrp::class.java)
            intentEachGroupDescription.putExtra("positionGrp",intent.getIntExtra("positionGrp",-1))
            intentEachGroupDescription.putExtra("Title",Title)
            startActivity(intentEachGroupDescription)

        }


        NewMember.setOnClickListener{
            var check :Int = 0
            val builder = AlertDialog.Builder(this)
            val inflater=LayoutInflater.from(this).inflate(R.layout.edittext_alert_1,null)
            builder.setTitle("Add Member")
            builder.setMessage("Enter the Name and e-m@il of member")


//            val editTextAlert1 = inflater.findViewById<EditText>(R.id.AddNewMember)
//            val editTextAlert2 = inflater.findViewById<EditText>(R.id.AddNewExchange)
//            val editTextAlert3 = inflater.findViewById<EditText>(R.id.AddNewSender_EditText)
            with(builder){
                setPositiveButton("Done"){
                        dialog,which ->
                    val emailFrn=inflater.findViewById<EditText>(R.id.emailFrnd).text
                    val nameFrnd=inflater.findViewById<EditText>(R.id.nameAlert).text
//                    scrollMemberList.append(nameFrnd.toString())
//                    scrollMemberList.append("\n")
//                    listMember.add(nameFrnd.toString())

//                    scrollemailList.append(emailFrn.toString())
//                    listEmail.add(emailFrn.toString())






//                    for (items in memberlist.indices){
//                        if (editTextAlert3.text.toString().trim()==memberlist[items].memberList.toString()||editTextAlert3.text.toString().trim()==memberlist[items].senderGive.toString()){
//                            check = 1
//                        }
//                    }
//                    if(check!=1){
//                        scrollMemberList.append(editTextAlert3.text.toString())
//                        scrollMemberList.append("\n")
//                    }
//                    check=0
//                    for (items in memberlist.indices){
//                        if (editTextAlert1.text.toString().trim()==memberlist[items].memberList.toString()||editTextAlert1.text.toString().trim()==memberlist[items].senderGive.toString()){
//                            check = 1
//                        }
//                    }
//                    if(check!=1){
//                        scrollMemberList.append(editTextAlert1.text.toString())
//                        scrollMemberList.append("\n")
//                    }
//                    memberlist.add(Members(editTextAlert3.text.toString().trim(),editTextAlert2.text.toString().toInt(),editTextAlert1.toString().trim()))
                    FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").document(Title!!).update("emailList",FieldValue.arrayUnion(emailFrn.toString())).addOnSuccessListener {
                        scrollemailList.append(emailFrn.toString())
                    }
                    FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid).collection("collection").document(Title!!).update("Memberskitne",FieldValue.arrayUnion(nameFrnd.toString())).addOnSuccessListener {
                        scrollMemberList.append(nameFrnd.toString())
                    }

                    //                    check = 0
                }
                setNegativeButton("Cancel"){
                        dialog,which ->
                    Toast.makeText(this@EachGroupDescription,"Cancelled it",Toast.LENGTH_SHORT).show()
                }
                setView(inflater)
                show()

            }


        }


    }


}