package com.example.express_sharing_app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Second_MyAdapter (private val transactionList :ArrayList<Members>):RecyclerView.Adapter<Second_MyAdapter.TransactionViewHolder>(){
    class TransactionViewHolder(itemView:View) : RecyclerView.ViewHolder(itemView){
        val debtMoney : TextView=itemView.findViewById(R.id.Debt_TextView)
        val debtFromWhom:TextView=itemView.findViewById(R.id.FromWhomDebtCollect_TextView)
        val debtkisseLiya:TextView=itemView.findViewById(R.id.PayerOfDebt_TextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.second_item,parent,false)
        return TransactionViewHolder(view)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        val transaction = transactionList[position]
        holder.debtMoney.text=transaction.money.toString()
        holder.debtFromWhom.text=transaction.memberList.toString()
        holder.debtkisseLiya.text=transaction.senderGive.toString()
    }

    override fun getItemCount(): Int {
        return transactionList.size
    }
}