package com.example.express_sharing_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class Profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        findViewById<ImageView>(R.id.imageView5).setOnClickListener {
            val intent : Intent = Intent(this , MainScreen::class.java)
            intent.putExtra("name",intent.getStringExtra("name"))
            startActivity(intent)
        }
    }
}