package com.example.express_sharing_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

class TemporaryChupa : AppCompatActivity() {

    private lateinit var recyclerViewTemp: RecyclerView
    private lateinit var billLogAdapterTemp: billsAdapter

//    private var EditButtn = findViewById<Button>(R.id.EditUpdate)
//    private var DeleteDebtButtn = findViewById<Button>(R.id.DeleteDebt)

    private lateinit var finBill : ArrayList<DebtSettleClass>
    private var linkmodel2: ArrayList<Description> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temporary_chupa)
        var tempalpha = ArrayList<MoneyList>()
//yahan se
        recyclerViewTemp=findViewById(R.id.temprorayRecyclerView)
        recyclerViewTemp.setHasFixedSize(true)
        recyclerViewTemp.layoutManager = LinearLayoutManager(this)

        //yahantk
        finBill= ArrayList()






        FirebaseFirestore.getInstance().collection("USERS").document(FirebaseAuth.getInstance().currentUser!!.uid)
            .collection("collection").addSnapshotListener{value,error ->
                for(dc : DocumentChange in value?.documentChanges!!){
                    if(dc.type==DocumentChange.Type.ADDED){
                        linkmodel2.add(dc.document.toObject<Description>(Description::class.java))
                    }
                }

                var budhu : ArrayList<Members> = linkmodel2.get(intent.getIntExtra("positionGrp",-1)).memberlist
//                for(i in budhu.indices){
//                    Toast.makeText(this@TemporaryChupa,budhu.get(i).money.toString(),Toast.LENGTH_LONG).show()
//                }
                for (items in budhu.indices) {
                    for (alpha in budhu[items].memberList.indices) {
                        finBill.add(
                            DebtSettleClass(
                                budhu[items].memberList[alpha].finalPayer,
                                budhu[items].memberList[alpha].debt,
                                budhu[items].senderGive
                            )
                        )
                    }
                }
                var grpSize=finBill.size
                for(i in 0 until (grpSize-1)){
                    for(j in i+1 until  grpSize){
                        if(finBill[i].fromWho==finBill[j].toWhom && finBill[i].toWhom==finBill[j].fromWho){
                            finBill[i].amountPay-=finBill[j].amountPay
                            finBill.removeAt(j)
                            grpSize--
                        }
                    }
                }
                findViewById<Button>(R.id.DeleteDebt).setOnClickListener{
                    finBill.removeAt(2)

                    billLogAdapterTemp=billsAdapter(finBill)
                    recyclerViewTemp.adapter=billLogAdapterTemp
                }
                findViewById<Button>(R.id.EditUpdate).setOnClickListener{
                    var intentToTransactionPage = Intent(this@TemporaryChupa,TransactionGrp::class.java)
                    intentToTransactionPage.putExtra("newfromWho",finBill[1].fromWho)
                    intentToTransactionPage.putExtra("newamountPay",finBill[1].amountPay.toInt())
                    intentToTransactionPage.putExtra("newtoWhome",finBill[1].toWhom)
                    finBill.removeAt(1)
                    startActivity(intentToTransactionPage)
                }
                billLogAdapterTemp=billsAdapter(finBill)
                recyclerViewTemp.adapter=billLogAdapterTemp


//                billLogAdapterTemp.setOnItemClickListenerAdapter(object  : billsAdapter.onItemClickListenerAdapter{
//
//                    override fun onItemClickAdapter(position: Int) {
//                        Toast.makeText(this@TemporaryChupa,"hi",Toast.LENGTH_LONG).show()
//                        startActivity(Intent(this@TemporaryChupa,this@TemporaryChupa::class.java))
//                        TODO("Not yet implemented")
//                    }
//
//
//                })
                billLogAdapterTemp.notifyDataSetChanged()


            }

    }



}