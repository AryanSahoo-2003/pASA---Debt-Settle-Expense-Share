package com.example.express_sharing_app

import android.os.Parcel
import android.os.Parcelable

data class Description(
    var Title : String="",
    var Reason:String="",
//    val memberList:MutableList<Members> ?=null,
    var memberlist:ArrayList<Members> = ArrayList(),
    var emailList : ArrayList<String> =ArrayList(),
    var Memberskitne:ArrayList<String> = ArrayList()
//    val transactions :Map<Map<String,String>,Int> ?=null

   ){
//    constructor(parcel: Parcel) : this(
//        parcel.readString().toString(),
//        parcel.readString().toString(),
//        parcel.readString().toString(),
//        parcel.createTypedArrayList(Members.CREATOR)?:ArrayList()
////        memberList=parcel.readParcelableList(Members.CREATOR)?: mutableListOf<Members>()
////        parcel.readValue()!!
//
//    ) {
//    }
//
//    override fun describeContents()=0
//
//    override fun writeToParcel(p0: Parcel, p1: Int)= with(p0) {
//        writeString(id)
//        writeString(title)
//        writeString(Reason)
//        writeTypedList(memberlist)
////        writeValue(transactions)
//    }
//
//    companion object CREATOR : Parcelable.Creator<Description> {
//        override fun createFromParcel(parcel: Parcel): Description {
//            return Description(parcel)
//        }
//
//        override fun newArray(size: Int): Array<Description?> {
//            return arrayOfNulls(size)
//        }
//    }
}
